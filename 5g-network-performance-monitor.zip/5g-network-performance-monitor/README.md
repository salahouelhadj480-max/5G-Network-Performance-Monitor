# 5G Network Performance Monitor

See README content in assistant message.